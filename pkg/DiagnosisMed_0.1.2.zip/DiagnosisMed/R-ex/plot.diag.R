### Name: plot.diag
### Title: Nomogram from 2x2 table diagnostic test
### Aliases: plot.diag
### Keywords: univar htest aplot

### ** Examples

#This will draw a ROC curve
mytest<-diagnosisI(364,22,17,211, print=TRUE, plot=TRUE)
#This is different, and will draw a nomogram
mytest<-diagnosisI(364,22,17,211)
plot(mytest)
#Draw a nomogram and print it's table - printing is optional
mytest<-diagnosisI(364,22,17,211)
plot(mytest,print=TRUE)
# The same as
plot(diagnosisI(364,22,17,211),print=TRUE)




