### Name: ROC
### Title: Draw a ROC curve, estimate good cut-offs and compute validity
###   measures for each cut-off
### Aliases: ROC
### Keywords: iplot univar htest

### ** Examples

# loading a dataset
data(tutorial)
# attaching a dataset
attach(tutorial)
# The reference standard is not in the correct format
# Recoding the reference standard to "positive" & "negative"
tutorial$Gold2<-as.factor(ifelse(Gold=="pos","positive","negative"))
# attaching the data set with the modifications
attach(tutorial)
# A little description of the data set to check if it is ok!
str(tutorial)
# Running ROC analysis with the standard options
ROC(Gold2,Test_B)



