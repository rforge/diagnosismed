### Name: diagnosis
### Title: Diagnostic test accuracy evaluation
### Aliases: diagnosis diagnosisI print.diag
### Keywords: univar htest

### ** Examples

# Simulating a dataset
mydata<-as.data.frame(rbind(c("positive","positive"),c("positive","negative"),
        c("negative","positive"),c("negative","negative")))
# Auxiliary vector to indicate the number of times to expand the lines
Freq<-as.numeric(c(173,13,27,638))
# Binding the dataset to the auxiliary vector
mydata<-as.data.frame(cbind(mydata,Freq))
# Naming the columns of the data set
colnames(mydata)<-c("Gold","mytest","Freq")
# A little description of the data set to check if it is ok!
str(mydata)
# Removing unwanted objects
rm(Freq)
# Expanding the four lines dataset to an adequate format
mydata<-expand(mydata, index.var = "Freq")
# Attaching the data set
attach(mydata)
# Running the diagnosis analysis
test<-diagnosis(Gold,mytest,print=FALSE)
print(test)
# The same as
diagnosis(Gold,mytest)
# Draw a nomogram from this test
test<-diagnosis(Gold,mytest,print=FALSE)
plot(test)
#Different from - draw a ROC curve from this test
diagnosis(Gold,mytest,plot=TRUE,print=FALSE)
#Inserting values from a 2x2 table
diagnosisI(364,22,17,211)



