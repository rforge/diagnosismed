### Name: interact.ROC
### Title: Interactively draw a ROC curve with your data
### Aliases: interact.ROC
### Keywords: dynamic iplot

### ** Examples

data(rocdata)
attach(rocdata)
interact.ROC(Gold,test2)



